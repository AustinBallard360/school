#include "Container.h"

// Constructor for Container class
Container::Container()
{
	book = NULL;
	next = NULL;
}